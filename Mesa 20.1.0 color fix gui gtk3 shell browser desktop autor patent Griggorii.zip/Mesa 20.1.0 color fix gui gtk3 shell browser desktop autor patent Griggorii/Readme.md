                                                                               Griggorii@gmail.com



apt install dconf-editor
